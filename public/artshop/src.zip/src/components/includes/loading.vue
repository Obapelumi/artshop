<template>
  <div id="art-loader"><i class="fa fa-spinner fa-spin"></i></div>
</template>
<script>
export default {
  
}
</script>
<style>
    #art-loader {
        height: 400px;
        font-size: 200px;
        color: #0dab76;
        /* margin-left: 50%; */
        text-align: center;
    }
</style>


