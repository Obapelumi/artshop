<template>
        <div class="about-us has-header">
            <art-page-header :page="'FAQs'"></art-page-header>
            <div class="container row">
              <div class="col-md-1"></div>
              <div class="col-md-10">
                <div class="about-us-content">
                  <h2>RETURN POLICY</h2>
                  <div class="wpb_text_column wpb_content_element" style="line-height: 30px">
                    <div class="wpb_wrapper">
                    <p>
                        Items sold on ArtShop.com.ng marketplace are sold by third party merchants. To improve our customers’ buying experience on, returns are made directly to the merchant by the buyer or to ArtShop.com.ng
                    </p>
                    <h3>Returns Guide</h3>
                    <p>
                        Ensure product to be returned is in the exact same condition as its original packaging along with all accessories (including manuals, warranty cards, certificate of authenticity) 
                        Do not accept packages that are damaged, ripped, opened or in bad condition upon delivery. 
                        The Merchant or Artshop.com.ng will not initiate refund/replacement for:
                        Any product that exhibits physical damage to the box, packaging, tags or to the product.
                        Any product that is returned without all original packaging and accessories, including the retail box, manuals, and all other items originally included with the product at the time of delivery.
                        Any product without a valid, readable, untampered serial number, including but not limited to products with missing, damaged, altered, or otherwise unreadable serial number.
                        Any product from which the UPC (Universal Product Code) has been removed from its original packaging.
                        Every promotional item delivered with the item must be returned along with the item.
                    </p>
                    <h3>Please Note</h3>
                    <p>
                        Return will only aptly take place if the item cannot be replaced or exchanged.
                        The issue of “returns” will be valid upon delivery not after the successful delivery i.e when the buyer acknowledges receipt of parcel. Hence, we urge buyers to inspect the condition of the order item(s) upon delivery before accepting the parcel
                    </p>
                    <h3>How to Return</h3>
                    <p>
                        If the buyer is not satisfied with the product(s) upon delivery, the buyer must instantly notify the delivery personnel and decline acceptance of the parcel. Only in exceptional situations would refunds and replacements be considered valid after successful delivery
                    </p>
                    <h3>Refunds</h3>
                    <ul>
                        <li>The refund will be processed after the “quality check” of the returned item.</li>
                        <li>Please note, here at Artshop.com.ng we refund you via a voucher that can be later redeemed and used at any time on artshop.com.ng</li>
                        <li>Cash refunds will only be considered in exceptional situations.</li>
                    </ul>

                    </div>
                  </div>
                  <h2>FAQs</h2>
                  <div class="wpb_text_column wpb_content_element" style="line-height: 30px">
                    <div class="wpb_wrapper">
                    <h3>What is the 3 Day Replacement Guarantee? </h3>
                    <p>
                        3 day Replacement Guarantee All products sold on Artshop.com.ng are covered under our 3 Day Refund/Replacement Guarantee. The Merchant should be notified of any problems, damages or defects within 3 days of receipt and ensure returns are made to the merchant within 3 days from date of delivery. 
                        The merchant will give a feedback within 3 business days after receipt of returns. If you do not receive a resolution in 3 business days, kindly contact our Customer Support Team. 

                    </p>
                    <!-- <br> -->
                    <h3>How do I get a defective item, ordered on Artshop replaced?</h3>
                    <p>    
                        In order to get a defective item replaced 
                        All returns for defective/broken/damaged/not as described products should be made directly to the merchant or Artshop.com.ng as the case may be. 
                        The cost of re-shipment and returns can be agreed between you and the merchant. 
                        Replacements are made by the merchant and a refund request will be initiated by merchant if a replacement is not available. 
                        While returning a product, make sure to keep the waybill received from the delivery company. This will help you prove that you actually returned the product. 

                    </p>
                    <h3>Why are my orders not delivered in a single package? </h3>
                    <p>
                        If the items in your orders are from different merchants, your items will arrive separately. If your order consists of items from one merchant your packages would be delivered together or separately. Not to worry, your orders will be delivered. 
                    </p>

                    <h3>How do I cancel an order?</h3> 
                    <p>
                        You can make a request for cancellation by contacting our Support Team on 
                        <a href="mailto:artshopng@gmail.com">artshopng@gmail.com</a>, 
                        <a href="mailto:Contactus@artshop.com.ng">Contactus@artshop.com.ng</a> 
                        or call us on <a href="tel:+234 (0) 80 51106313">+234 (0) 80 51106313</a>.  
                        Tweet at us <a href="https://twitter.com/ArtshopNG">@ArtShopNG</a>. 
                        If the cancellation request of your order is before your order has been shipped, ArtShopNG will effect a refund. 
                        If the cancellation request is after your order has been shipped, you will have to contact the merchant of the deal. 
                    </p>
                    <h3>How much are the delivery charges? </h3>
                    <p>
                        Artshopng provides delivery nationwide. All orders attract a delivery fee which is based on order weight and your shipping address.
                    </p>
                    <h3>What is the estimated delivery time? </h3>
                    <p>
                        The estimated time of delivery is 10 business days nationwide. 
                        With every order, an email/sms containing details of the order will be sent to you. Upon delivery, another email/sms will be sent to you. 
                    </p>
                    <h3>How much is Delivery? </h3>
                    <p>
                        As a different type of market place in the online community, Delivery rate may vary per location per weight of item. Detailed information on delivery rates are on the order summary page in your cart. 
                    </p>
                    <h3>What about warranty and hidden costs (sales tax etc.)?</h3>
                    <p>
                        There are no extra taxes, hidden costs or additional shipping charges. The price mentioned on the website is the final price. What you see is what you pay. Our prices are all inclusive. All taxes are included with the list prices.
                    </p> 
                    <h3>Does artshop deliver internationally?</h3>
                    <p>
                        Yes. Artshop Involves third party Logistics Company such as DHL and FedEx on deliveries outside Nigeria
                    </p>
                    </div>
                  </div>  
                </div>
              </div>
            </div>
          </div>
</template>

<script>
export default {
  
}
</script>

<style>
    .wpb_text_column h3 {
        text-transform: capitalize;
    }
</style>