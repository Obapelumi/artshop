<template>
        <div class="about-us has-header">
            <art-page-header :page="'Merchant-Agreement'"></art-page-header>
            <div class="container row">
              <div class="col-md-1"></div>
              <div class="col-md-10">
                <div class="about-us-content">
                  <h2>MERCHANT AGREEMENT</h2>
                  <div class="wpb_text_column wpb_content_element" style="line-height: 30px">
                    <div class="wpb_wrapper">
                    <h3>Account Registration</h3>
                    <p>
                        We will require some personal information about you and your company. All data are expected to be accurate and up-to-date. False details will lead to termination of your account with us.
                    </p>
                    <h3>Name</h3>
                    <p>
                        Your business name will be used to sign up as a merchant on ARTSHOPNG.
                    </p>
                    <h3>Software</h3> 
                    <p>
                        Our software comprises of mobile, web and hardware products collectively called the services.
                    </p>
                    <h3>Verification and Inspection</h3>
                    <p>
                        Upon successful sign up, we may need additional information such as driver’s license, national identity card and/or business license. We may also inspect your business location to prove legitimacy. Your refusal to any of the above may lead to your account being suspended or terminated.
                    </p>
                    <h3>Your ARTSHOPNG Account</h3> 
                    <p>
                        By becoming a ARTSHOPNG merchant, you confirm you’re a legal resident in your country of operation authorized to conduct business in the state in which you operate. Your ARTSHOPNG account may only be used for business purposes only. You are not allowed to use your ARTSHOPNG account to conduct illegal business activities of any sort that isn’t bound by this contract and acceptable by the state or federal government laws.
                    </p>
                    <h3>Our Role</h3> 
                    <p>
                        The Services allows ARTSHOPNG to receive card payments, however, we are not a bank nor do we offer banking services. We only facilitate processing of payments we receive from buyers, this requires us to enter agreements with Networks, processors, and acquiring banks.
                    </p>
                    <h3>Your Authorization</h3> 
                    <p>
                        You authorize us to hold, receive, and disburse funds on your behalf. This remains in full effect until your termination or closure of your ARTSHOPNG account.
                    </p> 
                    <h3>Underwriting</h3> 
                    <p>
                        ARTSHOPNG reviews all information submitted upon sign up and we may share information about you and your account with our processors and acquiring bank. You grant us permission to periodically obtain additional reports to determine whether you continue to meet requirements for An ARTSHOPNG account.
                    </p>
                    <h3>Our Fees</h3>
                    <p>
                        You agree to pay the applicable commission fee of 15% per item sold on our platform. Subject to the terms of this agreement, we reserve the right to change our fees upon 30 days advance notice. All balances and fees, charges, and payments collected or paid through the services are denominated in Nigerian Naira.
                    </p>
                    <h3>Access to ARTSHOPNG Account Funds</h3> 
                    <p>
                        Payouts are to your verified bank accounts. If we cannot debit or credit your bank account linked with your ARTSHOPNG account, we will unlink it from your ARTSHOPNG account. If you do not have an ACH-enabled bank account, you may request for a check chargeable to you.
                    </p>
                    <h3>Payout Schedule</h3> 
                    <p>
                        ARTSHOPNG will automatically initiate a payout to your bank account based on an agreement reached with you and the wire transfer fee of ₦110 is borne by you.
                    </p>
                    <h3>ARTSHOPNG balances</h3> 
                    <p>
                        We separate our corporate funds from yours and we will neither use your funds for our corporate purposes, nor any other purposes.
                    </p>
                    <h3>Receipts</h3> 
                    <p>
                        Buyers will be presented with purchase e-receipts for items above N500 and may opt in to receive digital receipts via SMS.
                    </p>
                    <h3>Taxes</h3>
                    <p>
                        You are responsible for collecting, withholding, reporting, and remitting correct taxes.
                    </p>
                    <h3>Customer Service</h3> 
                    <p>
                        You are responsible for issues relating to pricing, no shows by you, adjustments, functionality, and warranty of products. ARTSHOPNG is responsible for card processing, technical support, quality control, and feedback with customers.
                    </p>
                    <h3>Refunds and Returns</h3> 
                    <p>
                        In the event of returns, ARTSHOPNG will process returns initiated by buyer and if complaint is found true, we will return the goods back to you upon completion of investigation, and order a new item delivered to buyer. The cost incurred by returns is borne by you.
                    </p>
                    <h3>Privacy</h3> 
                    <p>
                        Your privacy is very important to us. You may receive information about buyers or third parties by using our service. Under no circumstances are you allowed to disclose or distribute any of such information or use this information for marketing purposes unless permitted to.
                    </p>
                    <h3>Your Content</h3> 
                    <p>
                        You will be able to upload or provide photos of your products matching our required standard and that are not offensive in any form. You grant us and our affiliates and successors permission to use or distribute publicly your Merchant content through the world in any media to promote the services.
                    </p>
                    <h3>Copyright and Trademark Infringement</h3>
                    <p>
                        ARTSHOPNG respects the copyright and trademark rights of others and asks you to do same.
                    </p>
                    <h3>Security</h3> 
                    <p>
                        We have put in place measures to secure your personal information from accidental loss or unauthorized use, however, we cannot guarantee that unauthorized parties will never defeat those measures or use your personal information for improper purposes.
                    </p>
                    <h3>Termination</h3>
                    <p>
                        If your ARTSHOPNG account is suspended or terminated for any reason, you must stop using the services and we reserve the right to delete all your information and account data on our servers.
                    </p>
                    <h3>Your Right to Terminate</h3> 
                    <p>
                        You may terminate your ARTSHOPNG account at any time. Any funds we are holding at the time of closure, less applicable fees, will be paid out to you according to your payout schedule. If an investigation is pending at the time you close your ARTSHOPNG account, we may hold funds until it is all resolved.
                    </p>
                    <h3>Suspension or Termination by Us</h3> 
                    <p>
                        We may terminate your account for any reason or no reason at any time upon notice to you.
                    </p>
                    <h3>Effect of Termination</h3> 
                    <p>
                        Termination does not exempt you from any obligations to pay fees, or other costs prior to the termination.
                    </p>
                    <h3>Dormant ARTSHOPNG Accounts</h3> 
                    <p>
                        If there is no activity in your ARTSHOPNG account for at least 6 months and you have a balance, we will send you an email or call you through the number associated with our ARTSHOPNG account and give you the option of keeping your account open and maintaining the balance, withdrawing the balance, or requesting a check. If you do not respond within 30 days, we will automatically close your account and escheat our funds according to the applicable law and if permitted.
                    </p>
                    </div>
                  </div>  
                </div>
              </div>
            </div>
          </div>
</template>

<script>
export default {
  
}
</script>

<style>
    .wpb_text_column h3 {
        text-transform: capitalize;
    }
</style>