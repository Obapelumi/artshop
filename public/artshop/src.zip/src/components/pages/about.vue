<template>
        <div class="about-us has-header">
            <art-page-header :page="'About'"></art-page-header>
            <div class="container row">
              <div class="col-md-1"></div>
              <div class="col-md-10">
                <div class="about-us-content">
                  <h2>ABOUT US</h2>
                  <div class="wpb_text_column wpb_content_element" style="line-height: 30px">
                    <div class="wpb_wrapper">
                    <p>
                        ArtShopNG seeks to be the world’s leading online marketplace for Nigeria Art, Crafts and Textile Prints, connecting people with art, crafts and textile prints they love. 
                    </p>
                    <!-- <br> -->
                    <p>    
                        ArtShopNG offers an unparalleled selection of paintings, drawings, sculpture, crafts and textile prints in a range of prices, and it provides artists and craftsmen with an expertly curated environment in which to exhibit and sell their work.
                    </p>
                    <!-- <br> -->
                    <p> 
                        Based in Lagos, Nigeria. ArtShopNG is redefining the experience of buying and selling art by making it easy, convenient and welcoming for both the buyers and sellers
                     </p>
                    </div>
                  </div>
                  <div class="wpb_single_image wpb_content_element vc_align_center">
                    <figure class="wpb_wrapper vc_figure">
                      <div class="vc_single_image-wrapper vc_box_border_grey"><img src="images/demo/about.jpg" alt="img 8" width="920" height="350" class="vc_single_image-img attachment-full"/></div>
                    </figure>
                  </div>
                  <div class="wpb_text_column wpb_content_element" style="line-height: 30px">
                    <div class="wpb_wrapper">
                      <p>ArtShopNG promotes the beauty of the Nigerian culture by creating an online community where crafters, artists and makers could sell their handmade, vintage goods and craft supplies not only providing the advantage of being open for business 24/7, but also the opportunity to broaden their reach to consumers across Nigeria, Africa and the rest of the world</p>
                    </div>
                  </div>
                  <div class="about-bottom">
                    <h2>CONTACT US</h2>
                    <div class="row">
                      <div class="about-bottom-left col-md-6">
                        <div class="wpb_wrapper">
                          <p>For inquiry on our products and services at Artshop.com.ng, you can reach us 24/7 on the Support Lines listed beside</p>
                          <p>Alongside that fill your name, mail and message thingy. Do you understand sir?</p>
                        </div>
                        <h2><router-link to="/merchant-agreement">READ OUR MERCHANT AGREEMENT</router-link></h2>
                        <br>
                      </div>
                      <div class="about-bottom-right col-md-6"><router-link to="/" title="ARTSHOP"><img src="images/logo/favicon.png" alt="Artshop" class="logo-img"/></router-link>
                        <div class="icon-box icon-box-style2">
                          <div class="icon-box-left"><i class="fa fa-map-marker"></i></div>
                          <div class="icon-box-right"><span>10, Emokaro street. Off Governor road. Ikotun. Lagos</span></div>
                        </div>
                        <div class="icon-box icon-box-style2">
                          <div class="icon-box-left"><i class="fa fa-phone"></i></div>
                          <div class="icon-box-right"><span>Phone : <a href="tel:+234 (0) 80 5110 6313">+234 (0) 80 5110 6313</a> <br>
                        <a href="tel:+234 (0) 81 8983 7848">+234 (0) 81 8983 7848</a>
</span></div>
                        </div>
                        <div class="icon-box icon-box-style2">
                          <div class="icon-box-left"><i class="fa fa-envelope-o"></i></div>
                          <div class="icon-box-right">
                              <span>Email : 
                                  <a href="mailto:contactus@artshop.com.ng">contactus@artshop.com.ng</a>
                              </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
</template>

<script>
export default {
  
}
</script>

<style>

</style>


